# My C Preprocessor

A beginner-level C project that reads a C source file, performs selected preprocessing operations, and generates an extended source file with the `.i` extension.

## Features
- Single-line and multi-line comment removal
- Local quoted-header inclusion
- Object-like macro substitution
- Basic function-like macro substitution
- `.i` output generation

## Requirements
- GCC
- GNU Make
- Ubuntu/Linux or another C development environment

## Build
```bash
make
```

## Run
```bash
./mypreprocessor inputfile.c
```

The output is written to `inputfile.i`.

## Project modules
- `main.c` — coordinates preprocessing stages
- `comment_removal.c/.h` — comment removal
- `file_inclusion.c/.h` — local header inclusion
- `macro_handler.c/.h` — macro substitution
- `Makefile` — build instructions

## Scope
This is an educational, simplified preprocessor, not a complete implementation of the C standard preprocessor. System headers may be preserved as include directives rather than expanded, depending on the implementation.

## Author
Mechatronics Engineering Graduate
